"""Run prediction engine on the 32 sample cases and compare to ground truth."""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(r"d:\btech\projects\orchestrate\orchestrate oct\hackerrank-orchestrate-october26")
sys.path.insert(0, str(ROOT))

from code.prediction_engine import PredictionEngine

# Load sample requests  
with open(ROOT / "dataset" / "sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    sample_requests = list(csv.DictReader(f))

# Load sample ground truth
with open(ROOT / "dataset" / "sample_output.csv", "r", encoding="utf-8") as f:
    expected = {r["case_id"]: r for r in csv.DictReader(f)}

print(f"Sample requests: {len(sample_requests)}")
print(f"Expected answers: {len(expected)}")
print()

# Run engine
engine = PredictionEngine(dataset_dir=ROOT / "dataset", enable_groq=False)

status_correct = 0
exact_match = 0
mismatches = []

for req in sample_requests:
    case_id = req["case_id"]
    result = engine.audit_case(req)
    
    exp = expected.get(case_id)
    if not exp:
        print(f"No expected answer for {case_id}")
        continue
    
    exp_status = exp["deletion_status"]
    our_status = result["deletion_status"]
    
    status_ok = exp_status == our_status
    if status_ok:
        status_correct += 1
    
    exp_steps = json.loads(exp["steps_json"])
    our_steps = json.loads(result["steps_json"])
    
    def normalize_step(s):
        return {
            "step_no": s.get("step_no"),
            "phase": s.get("phase"),
            "system_id": s.get("system_id"),
            "resource_id": s.get("resource_id"),
            "operation": s.get("operation"),
            "state": s.get("state"),
            "evidence_id": s.get("evidence_id"),
        }
    
    exp_norm = [normalize_step(s) for s in exp_steps]
    our_norm = [normalize_step(s) for s in our_steps]
    
    steps_match = exp_norm == our_norm
    
    if steps_match and status_ok:
        exact_match += 1
    else:
        issues = []
        if not status_ok:
            issues.append(f"STATUS: expected={exp_status} got={our_status}")
        if not steps_match:
            issues.append(f"STEPS: expected {len(exp_steps)} steps, got {len(our_steps)} steps")
            max_len = max(len(exp_norm), len(our_norm))
            for i in range(max_len):
                e = exp_norm[i] if i < len(exp_norm) else None
                o = our_norm[i] if i < len(our_norm) else None
                if e != o:
                    if e and o:
                        diffs = []
                        for k in ["phase", "system_id", "resource_id", "operation", "state", "evidence_id"]:
                            if e.get(k) != o.get(k):
                                diffs.append(f"{k}: exp={e.get(k)} got={o.get(k)}")
                        issues.append(f"  Step {i+1}: {', '.join(diffs)}")
                    elif e:
                        issues.append(f"  MISSING step {i+1}: sys={e['system_id']} res={e['resource_id']} op={e['operation']}")
                    else:
                        issues.append(f"  EXTRA step {i+1}: sys={o['system_id']} res={o['resource_id']} op={o['operation']}")
        
        mismatches.append((case_id, issues))

total = len(sample_requests)
print("=" * 70)
print(f"Status accuracy: {status_correct}/{total} ({100*status_correct/total:.1f}%)")
print(f"Exact row match: {exact_match}/{total} ({100*exact_match/total:.1f}%)")
print(f"Mismatched cases: {len(mismatches)}")
print()

for case_id, issues in mismatches:
    print(f"\n--- {case_id} ---")
    for iss in issues:
        print(f"  {iss}")

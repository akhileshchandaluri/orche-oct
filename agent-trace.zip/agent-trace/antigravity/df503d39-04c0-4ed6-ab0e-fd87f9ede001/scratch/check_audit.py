"""Check all audit_record references in sample_output.csv"""
import csv, json
root = r"d:\btech\projects\orchestrate\orchestrate oct\hackerrank-orchestrate-october26"
with open(f"{root}/dataset/sample_output.csv", "r", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        steps = json.loads(row["steps_json"])
        for s in steps:
            if "audit_record" in s.get("resource_id", ""):
                print(f"{row['case_id']}: resource={s['resource_id']} system={s['system_id']} op={s['operation']} evidence={s['evidence_id']}")

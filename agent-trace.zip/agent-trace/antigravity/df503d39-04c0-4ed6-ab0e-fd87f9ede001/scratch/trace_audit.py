"""Trace the mapping: how does user_50 (case_18) map to audit_record_6645?
Search system_activity for deletion_worker events near the case's reported_at time,
then check if there are security_service events in the same batch window."""
import csv, json, re
from datetime import datetime, timedelta
from pathlib import Path

root = Path(r"d:\btech\projects\orchestrate\orchestrate oct\hackerrank-orchestrate-october26\dataset")

# Load sample request for case_18
with open(root / "sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        if r["case_id"] in ["case_18", "case_20", "case_23"]:
            print(f"\n{'='*60}")
            print(f"Case: {r['case_id']}")
            print(f"  email: {r['email']}")
            print(f"  requested_at: {r['requested_at']}")
            print(f"  reported_status: {r['reported_status']}")
            print(f"  reported_at: {r['reported_at']}")
            print(f"  audit_at: {r['audit_at']}")
            
            # Look for security_service RETAIN_RECORD events near reported_at
            rep_dt = datetime.fromisoformat(r['reported_at'].replace('Z', '+00:00'))
            window_start = (rep_dt - timedelta(hours=3)).isoformat().replace('+00:00', 'Z')
            window_end = (rep_dt + timedelta(hours=1)).isoformat().replace('+00:00', 'Z')
            
            print(f"\n  Security events in window [{window_start} to {window_end}]:")
            with open(root / "system_activity.csv", "r", encoding="utf-8") as af:
                for act in csv.DictReader(af):
                    if act["source_system"] == "security_service" and act["event_type"] == "RETAIN_RECORD":
                        if window_start <= act["event_time"] <= window_end:
                            print(f"    {act['activity_id']}: res={act['resource_id']} time={act['event_time']} result={act['reported_result']} details={act['details'][:120]}")
            
            # Also look for deletion_worker events
            print(f"\n  Deletion worker events in window:")
            with open(root / "system_activity.csv", "r", encoding="utf-8") as af:
                for act in csv.DictReader(af):
                    if act["source_system"] == "deletion_worker":
                        if window_start <= act["event_time"] <= window_end:
                            print(f"    {act['activity_id']}: tgt={act['target_system']} type={act['event_type']} res={act['resource_id']} time={act['event_time']} result={act['reported_result']} details={act['details'][:100]}")

"""Deep-dive into the 3 mismatched sample cases to understand root causes."""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(r"d:\btech\projects\orchestrate\orchestrate oct\hackerrank-orchestrate-october26")

# Load sample ground truth
with open(ROOT / "dataset" / "sample_output.csv", "r", encoding="utf-8") as f:
    expected = {r["case_id"]: r for r in csv.DictReader(f)}

# Examine the 3 problem cases
for case_id in ["case_18", "case_20", "case_23"]:
    exp = expected[case_id]
    steps = json.loads(exp["steps_json"])
    print(f"\n{'='*60}")
    print(f"CASE: {case_id}  STATUS: {exp['deletion_status']}  STEPS: {len(steps)}")
    for s in steps:
        print(f"  step {s['step_no']}: {s['phase']} | {s['system_id']} | {s['resource_id']} | {s['operation']} | {s['state']} | ev={s['evidence_id']}")

# Also look at what the sample requests say for these cases
with open(ROOT / "dataset" / "sample_deletion_requests.csv", "r", encoding="utf-8") as f:
    requests = {r["case_id"]: r for r in csv.DictReader(f)}

for case_id in ["case_18", "case_20", "case_23"]:
    req = requests[case_id]
    print(f"\n--- {case_id} Request ---")
    print(f"  email: {req['email']}")
    print(f"  reported_status: {req['reported_status']}")
    print(f"  request_text: {req['request_text'][:100]}...")

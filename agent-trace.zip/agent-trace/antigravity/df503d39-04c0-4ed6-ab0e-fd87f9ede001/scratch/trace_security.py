"""Find security_service RETAIN_RECORD events and correlate them to user accounts
by checking the details field and temporal proximity to deletion batches."""
import csv, json, re
from datetime import datetime, timedelta
from pathlib import Path

root = Path(r"d:\btech\projects\orchestrate\orchestrate oct\hackerrank-orchestrate-october26\dataset")

# Load all security_service RETAIN_RECORD events from system_activity
security_events = []
with open(root / "system_activity.csv", "r", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        if row["source_system"] == "security_service" and row["event_type"] == "RETAIN_RECORD":
            security_events.append(dict(row))

print(f"Total security_service RETAIN_RECORD events: {len(security_events)}")

# Check if details contain user references
for ev in security_events[:5]:
    print(f"\n  {ev['activity_id']}: res={ev['resource_id']} time={ev['event_time']}")
    print(f"    details: {ev['details']}")

# Now find audit_record_6645 and audit_record_5569 specifically
for target in ['audit_record_6645', 'audit_record_5569', 'audit_record_4128', 'audit_record_2016']:
    matches = [e for e in security_events if e['resource_id'] == target]
    print(f"\n{target}: {len(matches)} matches in security events")
    for m in matches:
        print(f"  {m['activity_id']}: time={m['event_time']} details={m['details']}")

# Search for these across ALL system_activity with any reference
print("\n\nSearching ALL system_activity for audit_record_6645 and 5569:")
with open(root / "system_activity.csv", "r", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        if 'audit_record_6645' in str(row) or 'audit_record_5569' in str(row):
            print(f"  {row['activity_id']}: src={row['source_system']} tgt={row['target_system']} "
                  f"type={row['event_type']} res={row['resource_id']} details={row['details'][:150]}")

# Check the evidence_files manifest for any linked security evidence  
print("\n\nEvidence files with security_service origin:")
with open(root / "evidence_files.csv", "r", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        if 'security' in row.get('origin', '').lower() or 'security' in row.get('file_path', '').lower() or 'audit_ledger' in row.get('file_path', '').lower():
            print(f"  {row['file_id']}: {row['file_path']} origin={row.get('origin', '')} captured={row.get('captured_at', '')}")
